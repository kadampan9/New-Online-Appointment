package com.util;

public class MessageConstant {
    public static String COMMON_EXCEPTION = "Please try again later...";
    public static int COMMON_EXCEPTION_CODE = 1036;
    public static String SPECIALIZATION_MISSING = "Select the Specialization";
    public static int SPECIALIZATION_MISSING_CODE = 1001;
}
