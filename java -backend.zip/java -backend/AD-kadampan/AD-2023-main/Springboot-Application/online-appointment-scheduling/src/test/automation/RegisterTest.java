package com.automation;

import  com.dto.user.req.NewUserReq;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class RegisterTest {

    @PostConstruct
    public void initRegisterPage() {
        PageFactory.initElements(webDriver, this);
    }

    @Value("${app.url.register}")
    private String url;

    @FindBy(how = How.NAME, name = "FirstName")
    public WebElement txtFirstName;
    @FindBy(how = How.NAME, name = "LastName")
    public WebElement txtLastName;
    @FindBy(how = How.NAME, name = "EmailAddress")
    public WebElement txtEmail;
    @FindBy(how = How.NAME, name = "MobileNumber")
    public WebElement txtNic;
    @FindBy(how = How.NAME, name = "SuPassword")
    public WebElement txtMobile;
    @FindBy(how = How.NAME, name = "UserTypeId")
    public WebElement txtDob;
    @FindBy(how = How.NAME, using = "register")
    public WebElement lnkRegister;

    @Autowired
    private WebDriver webDriver;

    public void register(NewUserReq newUserReq) {
        webDriver.navigate().to(url);

        txtFirstName.sendKeys(newUserReq.getFirstName());
        txtLastName.sendKeys(newUserReq.getLastName());
        txtEmailAddress.sendKeys(newUserReq.getEmailAddress());
        txtMobileNumber.sendKeys(newUserReq.getMobileNumber());
        txtSuPassword.sendKeys(newUserReq.getSuPassword());
        txtUserTypeId.sendKeys(String.valueOf(newUserReq.UserTypeId()));

        clickRegister();
    }

    public void clickRegister() {
        lnkRegister.click();
        System.out.println("Register Success!");
    }
}
