package com.automation;

import com.automation.LoginTest;
import  com.dto.user.req.NewConsultantReq;
import  com.dto.user.req.NewUserReq;
import  com.dto.user.req.ResetUserPasswordReq;
import  com.dto.user.req.UpdateConsultantAppointmentReq;
import  com.dto.user.req.UpdateConsultantAvailabilityReq;
import  com.dto.user.req.UpdateConsultantDeviationReq ;
import  com.dto.user.req.UpdateConsultantReq ;
import  com.dto.user.req.UserLoginReq;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApplicationTest {

    @Autowired
    private LoginTest loginTest;
    @Autowired
    private RegisterTest registerTest;

    @Test
    void loginTest(){
        UserLoginReq userLoginReq = new UserLoginReq();
        userLoginReq.setUsername("puvi");
        userLoginReq.setPassword("12345678");
        //loginTest.login(userLoginReq);
    }

    @Test
    void registerTest(){
        NewUserReq newUserReq= new  NewUserReq ();
        NewUserReq.setFirstName("maheswaran");
        NewUserReq.setLastName("kadampan");
        NewUserReq.setEmailAddress("kadampan07@gmail.com");
        NewUserReq.setMobileNumber("0750326729");
        NewUserReq.setSuPassword("12345");
        NewUserReq .setUserTypeId(1);
        //registerTest.register(newUserReq);
    }
}

