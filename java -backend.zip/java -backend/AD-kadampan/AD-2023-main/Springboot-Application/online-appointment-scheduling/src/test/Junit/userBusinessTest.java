
package com.junit.product;

import com.business.UserManagement;
import  com.dto.user.req.NewConsultantReq;
import  com.dto.user.req.NewUserReq;
import  com.dto.user.req.ResetUserPasswordReq;
import  com.dto.user.req.UpdateConsultantAppointmentReq;
import  com.dto.user.req.UpdateConsultantAvailabilityReq;
import  com.dto.user.req.UpdateConsultantDeviationReq ;
import  com.dto.user.req.UpdateConsultantReq ;
import  com.dto.user.req.UserLoginReq;
import com.dto.user.common.res.CommonResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
public class UserManagementTest {

    @Autowired
    UserManagement userManagement;

    @Test
    public void createUserTest(){

        NewUserReq newUserReq= new NewUserReq();

        newUserReq.setFirstName("sivanujan");
        newUserReq.setLastName("maheswaran");
        newUserReq.setEmailAddress("vaddukoddai");
        newUserReq.setMobileNumber("0750326732");
        newUserReq.setSuPassword("123345");
        newUserReq.setUserTypeId(1);
        CommonResponse response = userManagement.ccreateUser(newUserReq);
        assertEquals(true, response.isRes());
    }

    @Test
    public void UpdateConsultantAppointmentTest(){

        UpdateConsultantAppointmentReq updateConsultantAppointmentReq = new UpdateConsultantAppointmentReq();
        updateConsultantAppointmentReq.setAppointmentId(1);
        updateConsultantAppointmentReq.setAppointmentDateTime("10:00 AM");
        updateConsultantAppointmentReq.setConsultantId(2);
        updateConsultantAppointmentReq.setUserId(3);

        CommonResponse response = userManagement.ccreateUser(updateConsultantAppointmentReq);
        assertEquals(true, response.isRes());
    }


}

