package com.dto.req;

public class GetUserDetailReq {
    private String searchKey;

    public GetUserDetailReq() {
    }

    public String getSearchKey() {
        return searchKey;
    }

    public void setSearchKey(String searchKey) {
        this.searchKey = searchKey;
    }
}
