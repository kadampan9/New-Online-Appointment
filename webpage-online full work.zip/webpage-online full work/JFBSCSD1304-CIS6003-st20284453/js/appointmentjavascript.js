// Selecting form and input elements
const form = document.querySelector("form");
const passwordInput = document.getElementById("password");
const passToggleBtn = document.getElementById("pass-toggle-btn");


// Function to display error messages
const showError = (field, errorText) => {
    field.classList.add("error");
    const errorElement = document.createElement("small");
    errorElement.classList.add("error-text");
    errorElement.innerText = errorText;
    field.closest(".form-group").appendChild(errorElement);
}

// Function to handle form submission
const handleFormData = (e) => {
    e.preventDefault();

    // Retrieving input elements
    
    const jobInput = document.getElementById("job");
    const dateInput = document.getElementById("date");
    const appointmenttimeInput = document.getElementById("appointmenttime");
    const consultantnameInput = document.getElementById("consultantname");
    // Getting trimmed values from input fields
    const job=jobInput .value.trim();
    const date=dateInput.value.trim();
    const appointmenttime=appointmenttimeInput.value.trim();
    const consultantname =consultantnameInput.value.trim();

    // Regular expression pattern for email validation
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    // Clearing previous error messages
    document.querySelectorAll(".form-group .error").forEach(field => field.classList.remove("error"));
    document.querySelectorAll(".error-text").forEach(errorText => errorText.remove());

    // Performing validation checks
    if (job=== "") {
        showError(jobInput, "select your job");
    }
    if (date=== "") {
        showError(dateInput , "select appointment date ");
    }
    
    if (appointmenttime=== "") {
        showError( appointmenttimeInput , "Enter your moblie no");
    }
    if (consultantname=== "") {
        showError(consultantnameInput, "Enter your user name");
    }
    

    // Checking for any remaining errors before form submission
    const errorInputs = document.querySelectorAll(".form-group .error");
    if (errorInputs.length > 0) return;

    // Submitting the form
    form.submit();
}

